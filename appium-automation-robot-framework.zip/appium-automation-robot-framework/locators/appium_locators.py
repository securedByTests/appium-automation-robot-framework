
## Chrome Launcher ###
btn_appium_chrome_acceptandcontinue_locator = 'id=com.android.chrome:id/terms_accept'
btn_appium_chrome_next_locator = 'com.android.chrome:id/next_button'
lnk_appium_chrome_nothanks_locator = 'com.android.chrome:id/negative_button'

txt_appium_chrome_searchbar_locator = 'com.android.chrome:id/search_box_text'
lbl_appium_chrome_searchbar_selecturl_locator = '//android.widget.TextView[@resource-id="com.android.chrome:id/line_2"]'