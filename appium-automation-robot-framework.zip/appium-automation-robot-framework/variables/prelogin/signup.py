# -*- coding: utf-8 -*-

# step 2
signup_test_firstname_variable = 'Scarlett'
signup_test_lastname_variable = 'Johansson'
signup_test_country_variable = 'India'
signup_test_zipcode_variable = '400082'
signup_test_state_variable = 'Maharashtra'
signup_test_city_variable = 'Mumbai'
signup_test_street_address_variable = 'Nargis Dutt Rd, Pali Hill'
signup_test_phonecode_variable = '91'
signup_test_phoneno_variable = '1234567890'

# empty values
blank_data_variable = ''

# invalid value
invalid_data_variable = '123Hello@#$'
validation_invalid_zip_variable = 'Invalid input, alphanumeric required'

#validation errors
validation_fname_variable = 'Please enter first name'
validation_lname_variable = 'Please enter last name'
validation_zip_variable = 'Please enter zipcode'
validation_phonecc_variable = 'Please enter country phone code'
validation_phone_variable = 'Please enter phone number'
validation_street_variable = 'Please enter address'
validation_city_variable = 'Please enter city'

welcome_screen_variable = 'Welcome'