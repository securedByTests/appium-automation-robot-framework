# -*- coding: utf-8 -*-

# valid credentials
test_login_password_variable = 'P@ssword1'

# # Invalid credentials
invalid_email_variable = 'invalid-user-id@test.com'
invalid_pwd_variable = 'password1'
not_valid_email_variable = 'webpro'

# Error Messages
authentication_error_mess_variable = 'Login failed. Please try again.'
emailreq_error_mess_variable = 'Please enter email address'
pwdreq_error_mess_variable = 'Please enter password'
emailnotvalid_mess_variable = 'Email not valid'